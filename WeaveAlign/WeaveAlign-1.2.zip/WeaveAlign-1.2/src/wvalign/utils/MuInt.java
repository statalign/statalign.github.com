package wvalign.utils;

public class MuInt {
	
	public int value;
	
	public MuInt(int value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return ""+value;
	}
	
}
